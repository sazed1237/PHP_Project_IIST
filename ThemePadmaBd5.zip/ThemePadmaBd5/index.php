<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <?php wp_head(); ?>
</head>
<body>

    <section class="container-fluid slider">
        <?php
        $qry1 = new WP_Query([
            'post_type' => 'post',
            'category_name' => 'slider'
        ]);
        ?>
    <div id="carouselExampleFade" class="carousel slide carousel-fade">
  <div class="carousel-inner">

    <?php 
    $rajib =0;
        while (have_posts()):the_post();
    $rajib++;
    ?>
    
    <div class="carousel-item <?= ($rajib==1)? 'active':'' ?> ">
        <?php the_post_thumbnail(); ?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php endwhile;?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    </section>


<!-- slider part End -->

<section class="container-fluid logo">
    <div class="row">
        <div class="col-lg-6">
            <?php the_custom_logo(); ?>
        </div>
        <div class="col-lg-6 text-end">
            <?php dynamic_sidebar('logo_right'); ?>
        </div>
    </div>
</section>

<!-- logo part end -->

<section class="container-fluid menu">

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <?php
        wp_nav_menu([
            'manu_locations' => 'TM',
            'menu_class' => 'navbar-nav Project_menu'
        ]);
        ?>
      <ul class="navbar-nav">
        <li class="nav-item">
          <!-- <a class="nav-link active" aria-current="page" href="#">Home</a> -->
        </li>
      </ul>
    </div>
  </div>
</nav>
</section>

<!-- menu part end -->

<section class="container-fluid card_heading">
    <div class="row card_heading_txt mt-5">
        <?php dynamic_sidebar('c_heading') ?>
    </div>

    <div class="txt_card">
        <div class="row card_heading_txt mt-5">

            <div class="col-lg-4">
            <div class="card" style="width: 16rem;">
            <?php dynamic_sidebar('t_card1') ?>
                <!-- <img src="..." class="card-img-top" alt="...">   -->
            </div>

            </div>
            <div class="col-lg-4">
            <div class="card" style="width: 16rem;">
            <?php dynamic_sidebar('t_card1') ?>
                <!-- <img src="..." class="card-img-top" alt="...">   -->
            </div>
            </div>
            <div class="col-lg-4">
            <div class="card" style="width: 16rem;">
            <?php dynamic_sidebar('t_card1') ?>
                <!-- <img src="..." class="card-img-top" alt="...">   -->
            </div>
            </div>
        </div>
    </div>
</section>


<section class="container-fluid separator">
    <div class="row card_heading_txt mt-5">
        <div class="col-lg-4 green mt-2">         
        <img src="<?php echo get_template_directory_uri() . '/assets/image/green-line.png' ?>" alt="">
        </div>
        <div class="col-lg-4 text-center">
            <h4>Recent Photos</h4>
            <p>Some latest project pictures</p>
        </div>
        <div class="col-lg-4 green mt-2">
        <img src="<?php echo get_template_directory_uri() . '/assets/image/green-line.png' ?>" alt="">
        </div>
    </div>
</section>

<!-- separetor part end -->


<section class="container-fluid card_heading">
  
    <div class="photo_card">
        <div class="row card_heading_txt mt-5">
            <div class="col-lg-3">
            <div class="card_1" style="width: 13rem;">
            <?php dynamic_sidebar('p_card1') ?>
                <!-- <img src="..." class="card-img-top" alt="...">   -->
            </div>

            </div>
            <div class="col-lg-3">
            <div class="card_1" style="width: 13rem;">
            <?php dynamic_sidebar('p_card2') ?>
                <!-- <img src="..." class="card-img-top" alt="...">   -->
            </div>
            </div>
            <div class="col-lg-3">
            <div class="card_1" style="width: 13rem;">
            <?php dynamic_sidebar('p_card3') ?>
                <!-- <img src="..." class="card-img-top" alt="...">   -->
            </div>
            </div>

            <div class="col-lg-3">
            <div class="card_1" style="width: 13rem;">
            <?php dynamic_sidebar('p_card4') ?>
                <!-- <img src="..." class="card-img-top" alt="...">   -->
            </div>
            </div>
        </div>
    </div>
</section>

<!-- photo part end -->


<section class="container-fluid separator">
    <div class="row card_heading_txt mt-5">
        <div class="col-lg-4 green mt-2">         
        <img src="<?php echo get_template_directory_uri() . '/assets/image/green-line.png' ?>" alt="">
        </div>
        <div class="col-lg-4 text-center">
            <h4>NEWS & EVENTS</h4>
            <p>CLICK HERE TO VIEW ALL</p>
        </div>
        <div class="col-lg-4 green mt-2">
        <img src="<?php echo get_template_directory_uri() . '/assets/image/green-line.png' ?>" alt="">
        </div>
    </div>
</section>

    

<footer class="container-fluid">
    <div class="row mt-5">
        <div class="col-lg-6 footer_left mt-5" style="width: 25rem;">
            <?php dynamic_sidebar('f_left') ?>
        </div>

        <div class="col-lg-6 footer_right mt-5" style="width: 30rem;">
            <?php dynamic_sidebar('f_right') ?>
        </div>
    </div>

    <div class="author">
        <div class="row mt-5">
            <div class="col-lg-6 author_left">
                <p>POWERED BY SOLUTION ART LTD</p>
            </div>
            <div class="col-lg-6 author_right">
                <p>COPYRIGHT © 2015. BANGLADESH BRIDGE AUTHORITY.</p>
            </div>
        </div>
    </div>
</footer>

    <?php wp_footer(); ?>
</body>
</html>