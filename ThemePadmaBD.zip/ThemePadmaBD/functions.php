
<?php 

wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );

wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0', true );

add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );
add_theme_support('post-thumbnails');


register_sidebar([
    'name' => 'logo',
    'id' => 'logoright',
    'before_widget' => '',
    'after_widget' => ''
]);

register_nav_menus([
    'TM' => 'Project_menu',

]);


register_sidebar([
    'name' => 'Hero title',
    'id' => 'herotitle',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'Hero Card img 1',
    'id' => 'card_img_1',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'Hero Card body 1',
    'id' => 'card_body_1',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'Hero Card img 2',
    'id' => 'card_img_2',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'Hero Card body 2',
    'id' => 'card_body_2',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'Hero Card img 3',
    'id' => 'card_img_3',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'Hero Card body 3',
    'id' => 'card_body_3',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'photo body 1',
    'id' => 'photo_body_1',
    'before_widget' => '',
    'after_widget' => ''
]);


register_sidebar([
    'name' => 'photo body 2',
    'id' => 'photo_body_2',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'photo body 3',
    'id' => 'photo_body_3',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'photo body 4',
    'id' => 'photo_body_4',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'Footer Left',
    'id' => 'footer_left',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'Footer right',
    'id' => 'footer_right',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'bottom left',
    'id' => 'bottom_left',
    'before_widget' => '',
    'after_widget' => ''
]);


register_sidebar([
    'name' => 'bottom right',
    'id' => 'bottom_right',
    'before_widget' => '',
    'after_widget' => ''
]);

?>