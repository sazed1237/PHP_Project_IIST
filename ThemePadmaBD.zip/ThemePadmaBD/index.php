<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <?php wp_head(); ?>
</head>
<body>
    <header class="container-fluid slider">
      <?php $qry1 = new WP_Query([
        'post_type'=>'post',
        'category_name'=>'slider'
      ])
       ?>
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">

    <?php
     $x= 0;
     while($qry1->have_posts()):$qry1->the_post();
     $x++;
     ?>
    <div class="carousel-item <?=($x == 1) ? 'active' : ''; ?> ">
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
      <?php the_post_thumbnail(); ?>
    </div>
    <?php endwhile;?>
    <!-- <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div> -->
  </div>

  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    </header>  

  <!-- header part end -->
    
    <!-- logo part start  -->

    <section class="container-fluid logo">
        <div class="row">
            <div class="col-sm-6">
                <?php the_custom_logo(); ?>
            </div>
            <div class="col-sm-6 logo_right text-end">
                <?php dynamic_sidebar('logoright'); ?>
            </div>
        </div>
    </section>

    <section class="container-fluid menu">
    <nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    
    <div class="collapse navbar-collapse" id="navbarNav">
        <?php
         wp_nav_menu([
        'Theme_locations'=>'TM',
        'menu_class'=>'navbar-nav Project_menu'

        ]) ?>
      <ul class="navbar-nav">
        <li class="nav-item">
          <!-- <a class="nav-link active" aria-current="page" href="#">Home</a> -->
        </li>        
      </ul>
    </div>
  </div>
</nav>
    </section>


    <section class="container-fluid">
        <div class="row hero_title mt-5">
            <?php dynamic_sidebar('herotitle'); ?>
        </div>


      <div class="row hero_card mt-5 d-flex">
        <div class="col-lg-4">
          <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('card_img_1') ?>
            <div class="card-body mt-4">
              <?php dynamic_sidebar('card_body_1') ?>            
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('card_img_2') ?>
            <div class="card-body mt-4">
              <?php dynamic_sidebar('card_body_2') ?>            
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('card_img_3') ?>
            <div class="card-body mt-4">
              <?php dynamic_sidebar('card_body_3') ?>            
            </div>
          </div>
        </div>                
      </div>
    </section>

  <section class="container-fluid line text-center  ">
    <div class="row">
      <div class="col-sm-5 green ">
        <img src=" <?php echo get_template_directory_uri() . '/assets/image/green-line.png' ?> "  alt="">
      </div>
      <div class="col-sm-2">
        <h4>Recent Photo</h4>
        <p>Some latest project pictures</p>
      </div>
      <div class="col-sm-5 green ">
      <img src=" <?php echo get_template_directory_uri() . '/assets/image/green-line.png' ?> " alt="">

      </div>
    </div>
  </section>



  <section class=" container-fluid photo text-center">
          <div class="row">
            <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('photo_body_1') ?>        
          </div>
            </div>
            <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('photo_body_2') ?>        
          </div>
            </div>
            <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('photo_body_3') ?>        
          </div>
            </div>
            <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('photo_body_4') ?>        
          </div>
            </div>
          </div>
  </section>

  <section class="container-fluid line text-center  ">
    <div class="row">
      <div class="col-sm-5 green ">
        <img src=" <?php echo get_template_directory_uri() . '/assets/image/green-line.png' ?> "  alt="">
      </div>
      <div class="col-sm-2">
        <h4>NEWS & EVENTS</h4>
        <p>CLICK HERE TO VIEW ALL</p>
      </div>
      <div class="col-sm-5 green ">
      <img src=" <?php echo get_template_directory_uri() . '/assets/image/green-line.png' ?> " alt="">

      </div>
    </div>
  </section>


  <section class="container-fluid slider mt-4">

        <?php $qry2 = new WP_Query([
          'post_type' => 'post',
          'category_name' => 'news'
        ]);?>

    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">

    <?php
     $x= 0;
     while($qry2->have_posts()):$qry2->the_post();
     $x++;
     ?>
    <div class="carousel-item <?=($x == 1) ? 'active' : ''; ?> ">
      <?php the_title(); ?>
    </div>
    <?php endwhile;?>
  </div>

  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
  </section>

  <footer class="container-fluid footer_main  ">
        <div class="row">
          <div class="col-lg-6 footer_left mt-5 text-end" style="width: 20rem;">
            <?php dynamic_sidebar('footer_left'); ?>
          </div>
          <div class="col-lg-6 footer_right mt-5" style="width: 25rem;">
          <?php dynamic_sidebar('footer_right'); ?>

          </div>
          <div class="footer_bottom d-flex mt-5" style="width: 55rem;">
            <div class="col-lg-6 bottom_right mt-2">
                <?php dynamic_sidebar('bottom_left') ?>
            </div>
            <div class=" col-lg-6 bottom_right mt-2 text-end">
            <?php dynamic_sidebar('bottom_right') ?>
            </div>
          </div>
        </div>
  </footer>




<?php wp_footer(); ?>
</body>
</html>