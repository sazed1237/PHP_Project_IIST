<footer class="container-fluid footer_main  ">
        <div class="row">
          <div class="col-lg-6 footer_left mt-5" style="width: 20rem;">
            <?php dynamic_sidebar('footer_left'); ?>
          </div>
          <div class="col-lg-6 footer_right mt-5" style="width: 25rem;">
          <?php dynamic_sidebar('footer_right'); ?>

          </div>
          <div class="footer_bottom d-flex mt-5" style="width: 55rem;">
            <div class="col-lg-6 bottom_right mt-2">
                <?php dynamic_sidebar('bottom_left') ?>
            </div>
            <div class=" col-lg-6 bottom_right mt-2 text-end">
            <?php dynamic_sidebar('bottom_right') ?>
            </div>
          </div>
        </div>
  </footer>