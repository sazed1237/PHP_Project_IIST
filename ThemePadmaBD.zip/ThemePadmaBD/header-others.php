<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <?php wp_head(); ?>
</head>
<body>
      

  <!-- header part end -->
    
    <!-- logo part start  -->

    <section class="container-fluid logo">
        <div class="row">
            <div class="col-sm-6">
                <?php the_custom_logo(); ?>
            </div>
            <div class="col-sm-6 logo_right text-end">
                <?php dynamic_sidebar('logoright'); ?>
            </div>
        </div>
    </section>

    <!-- logo End -->
        <!-- menu part start -->
    <section class="container-fluid menu-1">
    <nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    
    <div class="collapse navbar-collapse" id="navbarNav">
        <?php
         wp_nav_menu([
        'Theme_locations'=>'TM',
        'menu_class'=>'navbar-nav Project_menu'

        ]) ?>
      <ul class="navbar-nav">
        <li class="nav-item">
          <!-- <a class="nav-link active" aria-current="page" href="#">Home</a> -->
        </li>        
      </ul>
    </div>
  </div>
</nav>
    </section>
        <!-- menu part end -->