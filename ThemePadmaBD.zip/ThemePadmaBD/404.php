
<?php get_header('others'); ?>

<section class=" container text-center">
    <h1>Page Not Found</h1>
</section>

<?php get_footer(); ?>